(window.webpackJsonp = window.webpackJsonp || []).push([
    [40], {
        "+l9v": function(e, t) {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 13 13" width="13" height="13"><path fill="none" stroke="currentColor" stroke-width="1.2" d="M1 1l11 11m0-11L1 12"/></svg>'
        },
        "4Fxa": function(e, t) {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M12.143 20l1.714-12H12V7h5v1h-2.143l-1.714 12H15v1h-5v-1h2.143z"/></svg>'
        },
        "6w4h": function(e, t, n) {
            e.exports = {
                row: "row-1NK-hr1x",
                wrap: "wrap-tVR5Scov",
                breakpointNormal: "breakpointNormal-KzkqSNOX",
                breakpointMedium: "breakpointMedium-pbm8vBGT",
                breakpointSmall: "breakpointSmall-32f3vdsC"
            }
        },
        "7EmB": function(e, t, n) {
            e.exports = {
                range: "range-2i0X47Lu",
                valueInput: "valueInput-2CKQO1Lv",
                rangeSlider: "rangeSlider-suG521NL",
                input: "input-2kx6q_pc"
            }
        },
        "8XTa": function(e, t, n) {
            e.exports = {
                lineEndSelect: "lineEndSelect-25TizNST",
                right: "right-3IlPseCZ"
            }
        },
        "9gev": function(e, t, n) {
            e.exports = {
                dropdown: "dropdown-3Y1U1Nkm",
                normal: "normal-i7fM20bU",
                big: "big-2ruaa2z2",
                dropdownMenu: "dropdownMenu-3UShCdED"
            }
        },
        CaTF: function(e, t, n) {
            e.exports = {
                colorPicker: "colorPicker-3NIIN0Y8",
                row: "row-21qTMgcl",
                wrap: "wrap-1s7U_70a",
                fontStyleButton: "fontStyleButton-1445FY6N",
                dropdown: "dropdown-5N0LMJdQ",
                dropdownMenu: "dropdownMenu-yysG7ZzF",
                textarea: "textarea-2fko2YtQ",
                normal: "normal-AMDLZbUS",
                big: "big-1CfoFALo"
            }
        },
        EJl2: function(e, t, n) {
            e.exports = {
                input: "input-DGMBjOG0",
                control: "control-fEqNtKpC",
                item: "item-1ym_rlZM",
                cell: "cell-2byf6BGW",
                fragmentCell: "fragmentCell-1FhKQVpC",
                withTitle: "withTitle-QRL8YpBY",
                title: "title-3K1l5aiR"
            }
        },
        FIOl: function(e, t) {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M8.5 13.5a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm0 0H24"/></svg>'
        },
        G7lD: function(e, t, n) {
            e.exports = {
                range: "range-46to1pZu",
                disabled: "disabled-v1pYljFO",
                rangeSlider: "rangeSlider-10OqoFDT",
                rangeSliderMiddleWrap: "rangeSliderMiddleWrap-3-EULCcf",
                rangeSliderMiddle: "rangeSliderMiddle-3BlpfHSS",
                dragged: "dragged-36bXd7Hw",
                pointer: "pointer-23eauHul",
                rangePointerWrap: "rangePointerWrap-1vnhGySq"
            }
        },
        HWhk: function(e, t) {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path fill="currentColor" fillRule="evenodd" clipRule="evenodd" d="M7.5 13a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM5 14.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0zm9.5-1.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM12 14.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0zm9.5-1.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM19 14.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0z"/></svg>'
        },
        Q40t: function(e, t, n) {
            e.exports = {
                titleWrap: "titleWrap-1bavobjQ"
            }
        },
        ZRxn: function(e, t, n) {
            e.exports = {
                unit: "unit-b-yYYxjl",
                input: "input-124DCFwV",
                normal: "normal-3N4mfpQO",
                big: "big-1ixMJ1Cb",
                dropdown: "dropdown-NF5Htz1I",
                dropdownMenu: "dropdownMenu-36OGqXRr"
            }
        },
        ZcEB: function(e, t, n) {
            e.exports = {
                dropdown: "dropdown-2xTnctYy",
                menu: "menu-ZFNz6yWw"
            }
        },
        aSdR: function(e, t, n) {
            e.exports = {
                coordinates: "coordinates-1KIxFYVo",
                input: "input-1N6PPaVy"
            }
        },
        aw5J: function(e, t, n) {
            e.exports = {
                container: "container-1sHZXWOS",
                active: "active-2c5C-1Pl",
                disabled: "disabled-1s7-KBqG",
                icon: "icon-2ux26WKl"
            }
        },
        bvfV: function(e, t, n) {
            "use strict";

            function a(e) {
                var t = e.property,
                    n = Object(q.__rest)(e, ["property"]),
                    a = $({
                        property: t
                    }),
                    r = a[0],
                    i = a[1];
                return Q.a.createElement(ne.Checkbox, Object(q.__assign)({}, n, {
                    name: "toggle-enabled",
                    checked: r,
                    onChange: function() {
                        i(!r)
                    }
                }))
            }

            function r(e) {
                return Q.a.createElement("div", {
                    className: re()(ie.wrap, e.className)
                }, e.children)
            }

            function i(e) {
                var t = e.property,
                    n = e.disabled,
                    i = e.title,
                    o = e.className,
                    l = e.name,
                    c = Q.a.createElement("span", {
                        className: oe.title
                    }, i);
                return Q.a.createElement(r, {
                    className: o
                }, t && Q.a.createElement(a, {
                    name: l,
                    className: oe.checkbox,
                    property: t,
                    disabled: n,
                    label: c,
                    labelAlignBaseline: !te.isIE
                }), !t && c)
            }

            function o(e) {
                var t = e.id,
                    n = e.offset,
                    a = e.disabled,
                    r = e.checked,
                    o = e.title,
                    l = e.children;
                return Q.a.createElement(ee.a.Row, null, Q.a.createElement(ee.a.Cell, {
                    placement: "first",
                    verticalAlign: "adaptive",
                    offset: n,
                    "data-section-name": t,
                    colSpan: Boolean(l) ? void 0 : 2,
                    checkableTitle: !0
                }, Q.a.createElement(i, {
                    name: "is-enabled-" + t,
                    title: o,
                    disabled: a,
                    property: r
                })), Boolean(l) && Q.a.createElement(ee.a.Cell, {
                    placement: "last",
                    "data-section-name": t
                }, l))
            }

            function l(e) {
                var t = e.definition,
                    n = t.id,
                    a = t.properties,
                    r = a.checked,
                    i = a.disabled,
                    l = t.title,
                    c = e.offset,
                    s = $({
                        property: i,
                        defaultValue: !1
                    })[0];
                return Q.a.createElement(o, {
                    id: n,
                    offset: c,
                    checked: r,
                    title: l,
                    disabled: e.disabled || s
                })
            }

            function c(e) {
                var t = e.property,
                    n = $({
                        property: t
                    }),
                    a = n[0],
                    r = n[1];
                return Q.a.createElement(le.a, Object(q.__assign)({}, e, {
                    lineStyle: a,
                    lineStyleChange: r
                }))
            }

            function s(e) {
                function t(e, t) {
                    var n, r = {
                        borderTopWidth: e
                    };
                    return Q.a.createElement("div", {
                        className: se.item
                    }, Q.a.createElement("div", {
                        className: ae(se.bar, (n = {}, n[se.isActive] = e === a && !t, n)),
                        style: r
                    }, " "))
                }
                var n, a = e.value,
                    r = e.items,
                    i = void 0 === r ? ue : r,
                    o = e.disabled,
                    l = e.onChange;
                return Q.a.createElement(ce.a, {
                    disabled: o,
                    hideArrowButton: !0,
                    className: se.lineWidthSelect,
                    items: (n = i, n.map(function(e) {
                        return {
                            value: e,
                            selectedContent: t(e, !0),
                            content: t(e)
                        }
                    })),
                    value: a,
                    onChange: l,
                    "data-name": "line-width-select"
                })
            }

            function u(e) {
                var t = e.property,
                    n = $({
                        property: t
                    }),
                    a = n[0],
                    r = n[1];
                return Q.a.createElement(s, Object(q.__assign)({}, e, {
                    value: a,
                    onChange: r
                }))
            }

            function d(e, t, n) {
                var a = Object(K.useState)(e),
                    r = a[0],
                    i = a[1],
                    o = Object(K.useRef)(r);
                return Object(K.useEffect)(function() {
                    i(e)
                }, [e, n]), [r, function(e) {
                    o.current = e, i(e)
                }, function() {
                    t(o.current)
                }, function() {
                    o.current = e, i(e)
                }]
            }

            function p(e) {
                var t = e.property,
                    n = Object(q.__rest)(e, ["property"]),
                    a = Object(K.useState)(performance.now()),
                    r = a[0],
                    i = a[1],
                    o = $({
                        property: t,
                        handler: function() {
                            return i(performance.now())
                        }
                    }),
                    l = o[0],
                    c = o[1],
                    s = d(l, c, r);
                return Q.a.createElement(m, Object(q.__assign)({}, n, {
                    valueHash: r,
                    sharedBuffer: s
                }))
            }

            function m(e) {
                var t = e.sharedBuffer,
                    n = e.min,
                    a = e.max,
                    r = e.step,
                    i = Object(q.__rest)(e, ["sharedBuffer", "min", "max", "step"]),
                    o = t[0],
                    l = t[1],
                    c = t[2],
                    s = t[3],
                    u = Object(K.useRef)(null),
                    d = Object(K.useRef)(null),
                    p = {
                        flushed: !1
                    };
                return Q.a.createElement(ge, Object(q.__assign)({}, i, {
                    ref: d,
                    onValueChange: function(e, t) {
                        l(e), "step" !== t || p.flushed || (c(), p.flushed = !0)
                    },
                    onKeyDown: function(e) {
                        if (!e.defaultPrevented && !p.flushed) switch (Object(me.hashFromEvent)(e.nativeEvent)) {
                            case 27:
                                s(), p.flushed = !0;
                                break;
                            case 13:
                                e.preventDefault();
                                var t = Object(pe.ensureNotNull)(d.current).getClampedValue();
                                null !== t && (l(t), c(), p.flushed = !0)
                        }
                    },
                    onBlur: function(e) {
                        var t, n = Object(pe.ensureNotNull)(u.current);
                        n.contains(document.activeElement) || n.contains(e.relatedTarget) || null === (t = Object(pe.ensureNotNull)(d.current).getClampedValue()) || p.flushed || (l(t), c(), p.flushed = !0)
                    },
                    value: o,
                    roundByStep: !1,
                    containerReference: function(e) {
                        u.current = e
                    },
                    inputMode: "numeric",
                    min: n,
                    max: a,
                    step: r
                }))
            }

            function f(e, t, n) {
                return null !== (t = g(t)) && void 0 !== n && (n = Math.max(b(t), n)),
                    function(e, t) {
                        if (null === e) return "";
                        return new be.NumericFormatter(t).format(e)
                    }(t, n)
            }

            function h(e) {
                var t = 0;
                return e.inheritPrecisionFromStep && e.step <= 1 && (t = b(e.step)), Math.max(e.precision, t) || void 0
            }

            function b(e) {
                var t = Math.trunc(e).toString();
                return Object(he.clamp)(be.NumericFormatter.formatNoE(e).length - t.length - 1, 0, 15)
            }

            function v(e, t) {
                return new be.NumericFormatter(t).parse(e)
            }

            function g(e) {
                return "number" == typeof e && Number.isFinite(e) ? e : null
            }

            function E(e) {
                var t = e.color,
                    n = e.thickness,
                    a = e.thicknessItems,
                    r = e.noAlpha,
                    i = $({
                        property: t
                    }),
                    o = i[0],
                    l = i[1],
                    c = $(n ? {
                        property: n
                    } : {
                        defaultValue: void 0
                    }),
                    s = c[0],
                    u = c[1];
                return Q.a.createElement(we.a, Object(q.__assign)({}, e, {
                    color: o ? Object(ye.rgbToHexString)(Object(ye.parseRgb)(o)) : null,
                    onColorChange: function(e) {
                        var t = o ? Object(Ne.alphaToTransparency)(Object(ye.parseRgba)(o)[3]) : 0;
                        l(Object(Ne.generateColor)(String(e), t, !0))
                    },
                    thickness: s,
                    thicknessItems: a,
                    onThicknessChange: u,
                    opacity: r ? void 0 : o ? Object(ye.parseRgba)(o)[3] : void 0,
                    onOpacityChange: r ? void 0 : function(e) {
                        l(Object(Ne.generateColor)(o, Object(Ne.alphaToTransparency)(e), !0))
                    }
                }))
            }

            function _(e) {
                var t = e.property,
                    n = $({
                        property: t
                    }),
                    a = n[0],
                    r = n[1];
                return Q.a.createElement(Me, Object(q.__assign)({}, e, {
                    lineEnd: a,
                    lineEndChange: r
                }))
            }

            function y(e) {
                var t = e.children,
                    n = e.className,
                    a = e.breakPoint,
                    i = void 0 === a ? "Normal" : a;
                return K.createElement(r, {
                    className: ae(Te.wrap, n, Te["breakpoint" + i])
                }, K.Children.map(t, function(e) {
                    return K.isValidElement(e) ? K.createElement("span", {
                        key: null === e.key ? void 0 : e.key,
                        className: Te.row
                    }, e) : e
                }))
            }

            function w(e) {
                var t, n, a = e.definition,
                    r = a.id,
                    i = a.properties,
                    l = i.checked,
                    s = i.disabled,
                    d = i.leftEnd,
                    m = i.rightEnd,
                    f = i.value,
                    h = i.extendLeft,
                    b = i.extendRight,
                    v = a.title,
                    g = a.valueMin,
                    w = a.valueMax,
                    N = a.valueStep,
                    C = a.valueUnit,
                    S = a.extendLeftTitle,
                    k = a.extendRightTitle,
                    O = e.offset,
                    V = $({
                        property: l,
                        defaultValue: !0
                    })[0],
                    j = $({
                        property: s,
                        defaultValue: !1
                    })[0],
                    x = Re({
                        watchedValue: g,
                        defaultValue: void 0
                    }),
                    M = Re({
                        watchedValue: w,
                        defaultValue: void 0
                    }),
                    T = Re({
                        watchedValue: N,
                        defaultValue: void 0
                    }),
                    P = Re({
                        watchedValue: C,
                        defaultValue: void 0
                    }),
                    R = e.disabled || !V;
                return Q.a.createElement(K.Fragment, null, Q.a.createElement(o, {
                    id: r,
                    offset: O,
                    checked: l,
                    title: v,
                    disabled: e.disabled || j
                }, Q.a.createElement(y, {
                    className: Fe.line,
                    breakPoint: "Small"
                }, Q.a.createElement(K.Fragment, null, function() {
                    var t = e.definition,
                        n = t.properties,
                        a = n.color,
                        r = n.width,
                        i = t.widthValues;
                    return a ? Q.a.createElement("span", {
                        className: Fe.control
                    }, Q.a.createElement(E, {
                        color: a,
                        thickness: r,
                        disabled: R,
                        thicknessItems: i
                    })) : r && Q.a.createElement("span", {
                        className: Fe.control
                    }, Q.a.createElement(u, {
                        items: i,
                        property: r,
                        disabled: R
                    }))
                }(), (n = e.definition.properties.style) && Q.a.createElement("span", {
                    className: Fe.control
                }, Q.a.createElement(c, {
                    property: n,
                    disabled: R
                }))), (d || m || f) && Q.a.createElement(K.Fragment, null, Q.a.createElement(K.Fragment, null, d && Q.a.createElement(_, {
                    className: Fe.control,
                    property: d,
                    disabled: R,
                    "data-name": "left-end-select"
                }), m && Q.a.createElement(_, {
                    className: Fe.control,
                    property: m,
                    disabled: R,
                    "data-name": "right-end-select",
                    isRight: !0
                })), (t = e.definition.valueType, f && Q.a.createElement("span", {
                    className: ae(Fe.valueInput, Fe.control)
                }, Q.a.createElement(p, {
                    className: Fe.input,
                    property: f,
                    min: x,
                    max: M,
                    step: T,
                    disabled: R,
                    mode: void 0 !== t ? Pe[t] : void 0,
                    name: "line-value-input"
                }), Q.a.createElement("span", {
                    className: Fe.valueUnit
                }, P)))))), h && Q.a.createElement(o, {
                    id: r + "ExtendLeft",
                    offset: O,
                    checked: h,
                    title: S,
                    disabled: e.disabled || j
                }), b && Q.a.createElement(o, {
                    id: r + "ExtendRight",
                    offset: O,
                    checked: b,
                    title: k,
                    disabled: e.disabled || j
                }))
            }

            function N(e) {
                var t = e.definition,
                    n = t.id,
                    a = t.properties,
                    i = a.color,
                    l = a.checked,
                    c = a.disabled,
                    s = t.title,
                    u = t.noAlpha,
                    d = e.offset,
                    p = $({
                        property: l,
                        defaultValue: !0
                    })[0],
                    m = $({
                        property: c,
                        defaultValue: !1
                    })[0],
                    f = e.disabled || !p;
                return Q.a.createElement(o, {
                    id: n,
                    offset: d,
                    checked: l,
                    title: s,
                    disabled: e.disabled || m
                }, Q.a.createElement(r, null, Q.a.createElement(E, {
                    color: i,
                    disabled: f,
                    noAlpha: u
                })))
            }

            function C(e) {
                var t, n = e.value,
                    a = e.disabled,
                    r = e.onChange;
                return Q.a.createElement("div", {
                    className: ae(Ae.wrap, (t = {}, t[Ae.disabled] = a, t))
                }, Q.a.createElement(Be.a, {
                    hideInput: !0,
                    color: ze.a["color-tv-blue-500"],
                    opacity: 1 - n / 100,
                    onChange: function(e) {
                        r(100 - 100 * e)
                    }
                }))
            }

            function S(e) {
                var t = e.property,
                    n = Object(q.__rest)(e, ["property"]),
                    a = $({
                        property: t
                    }),
                    r = a[0],
                    i = a[1];
                return K.createElement(C, Object(q.__assign)({}, n, {
                    value: r,
                    onChange: i
                }))
            }

            function k(e) {
                var t = e.definition,
                    n = t.id,
                    a = t.properties,
                    i = a.transparency,
                    l = a.checked,
                    c = a.disabled,
                    s = t.title,
                    u = e.offset,
                    d = $({
                        property: l,
                        defaultValue: !0
                    })[0],
                    p = $({
                        property: c,
                        defaultValue: !1
                    })[0],
                    m = e.disabled || !d;
                return Q.a.createElement(o, {
                    id: n,
                    offset: u,
                    checked: l,
                    title: s,
                    disabled: e.disabled || p
                }, Q.a.createElement(r, null, Q.a.createElement(S, {
                    property: i,
                    disabled: m
                })))
            }

            function O(e) {
                function t(e, t) {
                    return Q.a.createElement("span", {
                        className: Ie.colorPicker
                    }, Q.a.createElement(E, {
                        color: e,
                        disabled: v,
                        noAlpha: t
                    }))
                }
                var n = e.definition,
                    a = n.id,
                    i = n.properties,
                    l = i.color1,
                    c = i.color2,
                    s = i.checked,
                    u = i.disabled,
                    d = n.title,
                    p = n.noAlpha1,
                    m = n.noAlpha2,
                    f = e.offset,
                    h = $({
                        property: s,
                        defaultValue: !0
                    })[0],
                    b = $({
                        property: u,
                        defaultValue: !1
                    })[0],
                    v = e.disabled || !h;
                return Q.a.createElement(o, {
                    id: a,
                    offset: f,
                    checked: s,
                    title: d,
                    disabled: e.disabled || b
                }, Q.a.createElement(r, {
                    className: Ie.twoColors
                }, t(l, p), t(c, m)))
            }

            function V(e) {
                var t = e.property,
                    n = e.options,
                    a = Object(q.__rest)(e, ["property", "options"]),
                    r = $({
                        property: t
                    }),
                    i = r[0],
                    o = r[1],
                    l = Object(We.a)();
                return Object(K.useEffect)(function() {
                    var e = function() {
                        return l()
                    };
                    return n.subscribe(e),
                        function() {
                            return n.unsubscribe(e)
                        }
                }, []), Q.a.createElement(ce.a, Object(q.__assign)({}, a, {
                    onChange: o,
                    value: i,
                    items: n.value().map(function(e) {
                        return {
                            content: e.title,
                            value: e.value
                        }
                    })
                }))
            }

            function j(e) {
                var t = e.definition,
                    n = t.id,
                    a = t.properties,
                    i = a.checked,
                    l = a.value,
                    c = a.unitOptionsValue,
                    s = a.disabled,
                    u = t.min,
                    d = t.max,
                    m = t.step,
                    f = t.title,
                    h = t.unit,
                    b = t.unitOptions,
                    v = t.type,
                    g = e.offset,
                    E = $({
                        property: i,
                        defaultValue: !0
                    })[0],
                    _ = $({
                        property: s,
                        defaultValue: !1
                    })[0],
                    w = Re({
                        watchedValue: u,
                        defaultValue: void 0
                    }),
                    N = Re({
                        watchedValue: d,
                        defaultValue: void 0
                    }),
                    C = Re({
                        watchedValue: m,
                        defaultValue: void 0
                    }),
                    S = Re({
                        watchedValue: h,
                        defaultValue: void 0
                    }),
                    k = Object(K.useContext)(De.b),
                    O = e.disabled || !E;
                return Q.a.createElement(o, {
                    id: n,
                    offset: g,
                    checked: i,
                    title: f,
                    disabled: e.disabled || _
                }, Q.a.createElement(r, null, Q.a.createElement(y, null, Q.a.createElement(p, {
                    className: ae(Le.input, k[n] && Le[k[n]]),
                    property: l,
                    min: w,
                    max: N,
                    step: C,
                    disabled: O,
                    mode: Pe[v],
                    name: "number-input"
                }), c && Q.a.createElement(V, {
                    className: Le.dropdown,
                    menuClassName: Le.dropdownMenu,
                    disabled: O,
                    property: c,
                    options: Object(pe.ensureDefined)(b),
                    "data-name": "unit-options-dropdown"
                })), Q.a.createElement("span", {
                    className: Le.unit
                }, S)))
            }

            function x(e) {
                var t = e.definition,
                    n = t.id,
                    a = t.properties,
                    r = a.checked,
                    i = a.disabled,
                    l = t.childrenDefinitions,
                    c = t.title,
                    s = e.offset,
                    u = $({
                        property: r,
                        defaultValue: !0
                    })[0],
                    d = $({
                        property: i,
                        defaultValue: !1
                    })[0],
                    p = e.disabled || !u;
                return Q.a.createElement(Q.a.Fragment, null, Q.a.createElement(o, {
                    id: n,
                    offset: s,
                    checked: r,
                    title: c,
                    disabled: e.disabled || d
                }), l.map(function(e) {
                    return Q.a.createElement(G, {
                        key: e.id,
                        disabled: p,
                        definition: e,
                        offset: !0
                    })
                }))
            }

            function M(e) {
                var t = e.property,
                    n = $({
                        property: t
                    }),
                    a = n[0],
                    r = n[1];
                return Q.a.createElement(He.a, Object(q.__assign)({}, e, {
                    fontSize: a,
                    fontSizeChange: r,
                    "data-name": "font-size-select"
                }))
            }

            function T(e) {
                var t = e.className,
                    n = e.checked,
                    a = e.icon,
                    r = e.disabled,
                    i = e.onClick;
                return Q.a.createElement("div", Object(q.__assign)({
                    className: re()(t, Xe.container, n && !r && Xe.active, r && Xe.disabled),
                    onClick: r ? void 0 : i,
                    "data-role": "button"
                }, Object(ke.a)(e)), Q.a.createElement(Ue.a, {
                    className: Xe.icon,
                    icon: a
                }))
            }

            function P(e) {
                var t = e.icon,
                    n = e.className,
                    a = e.property,
                    r = e.disabled,
                    i = $({
                        property: a
                    }),
                    o = i[0],
                    l = i[1];
                return K.createElement(T, Object(q.__assign)({
                    className: n,
                    icon: t,
                    checked: o,
                    onClick: function() {
                        l(!o)
                    },
                    disabled: r
                }, Object(ke.a)(e)))
            }

            function R(e) {
                var t = e.value,
                    n = e.className,
                    a = e.onChange,
                    r = e.disabled,
                    i = e.readonly,
                    o = e.name,
                    l = e.highlight,
                    c = e.onFocus,
                    s = e.onBlur,
                    u = e.intent,
                    d = e.borderStyle,
                    p = void 0 === d ? "thin" : d,
                    m = e.size,
                    f = void 0 === m ? "medium" : m,
                    h = e.removeRoundBorder,
                    b = void 0 === h ? 0 : h,
                    v = e.highlightRemoveRoundBorder,
                    g = void 0 === v ? 0 : v,
                    E = Object(Ge.a)(b),
                    _ = Object(Ge.a)(g);
                return K.createElement("span", {
                    className: ae(qe.container, n, qe["intent-" + u], qe["border-" + p], qe["size-" + f], r && qe.disabled, i && qe.readonly, E, l && qe.highlight)
                }, K.createElement("textarea", {
                    className: qe.textarea,
                    value: t,
                    onChange: function(e) {
                        r || i || a(e.currentTarget.value)
                    },
                    onFocus: c,
                    onBlur: s,
                    disabled: r,
                    readOnly: i,
                    name: o
                }), l && K.createElement("span", {
                    className: ae(qe.shadow, _)
                }))
            }

            function F(e) {
                return e = Object(Ye.a)(e), K.createElement(R, Object(q.__assign)({}, e))
            }

            function B(e) {
                var t = e.property,
                    n = Object(q.__rest)(e, ["property"]),
                    a = $({
                        property: t
                    }),
                    r = a[0],
                    i = a[1];
                return K.createElement(F, Object(q.__assign)({}, n, {
                    value: r,
                    onChange: i
                }))
            }

            function z(e) {
                function t(e, t, n) {
                    return e ? Q.a.createElement(P, {
                        className: Je.fontStyleButton,
                        icon: t,
                        property: e,
                        disabled: te,
                        "data-name": n
                    }) : null
                }

                function n() {
                    return Q.a.createElement(K.Fragment, null, u && Q.a.createElement("div", {
                        className: Je.colorPicker
                    }, Q.a.createElement(E, {
                        color: u,
                        disabled: te
                    })), d && V && Q.a.createElement(M, {
                        property: d,
                        fontSizes: V,
                        disabled: te
                    }))
                }

                function a() {
                    return Q.a.createElement(K.Fragment, null, t(f, Ke, "toggle-bold"), t(h, Qe, "toggle-italic"))
                }

                function i(t, n, a, r, i, l) {
                    return a ? Q.a.createElement(o, {
                        id: c + "ColorSelect",
                        offset: I,
                        checked: n,
                        title: t,
                        disabled: e.disabled || L
                    }, Q.a.createElement(E, {
                        color: a,
                        thickness: i,
                        thicknessItems: l,
                        disabled: te || r
                    })) : null
                }
                var l = e.definition,
                    c = l.id,
                    s = l.properties,
                    u = s.color,
                    d = s.size,
                    p = s.checked,
                    m = s.disabled,
                    f = s.bold,
                    h = s.italic,
                    b = s.text,
                    v = s.alignmentHorizontal,
                    g = s.alignmentVertical,
                    _ = s.backgroundVisible,
                    w = s.backgroundColor,
                    N = s.borderVisible,
                    C = s.borderColor,
                    S = s.borderWidth,
                    k = s.wrap,
                    O = l.title,
                    V = l.sizeItems,
                    j = l.alignmentTitle,
                    x = l.alignmentHorizontalItems,
                    T = l.alignmentVerticalItems,
                    R = l.backgroundTitle,
                    F = l.borderTitle,
                    z = l.borderWidthItems,
                    A = l.wrapTitle,
                    I = e.offset,
                    D = Object(K.useContext)(De.a),
                    W = $({
                        property: p,
                        defaultValue: !0
                    })[0],
                    L = $({
                        property: m,
                        defaultValue: !1
                    })[0],
                    H = $({
                        property: g,
                        defaultValue: void 0
                    }),
                    U = H[0],
                    X = H[1],
                    G = $({
                        property: v,
                        defaultValue: void 0
                    }),
                    Y = G[0],
                    q = G[1],
                    J = $({
                        property: _,
                        defaultValue: !1
                    })[0],
                    Z = $({
                        property: N,
                        defaultValue: !1
                    })[0],
                    te = e.disabled || !W;
                return Q.a.createElement(K.Fragment, null, O ? Q.a.createElement(o, {
                    id: c,
                    offset: I,
                    checked: p,
                    title: O,
                    disabled: e.disabled || L
                }, Q.a.createElement(y, {
                    breakPoint: "Small"
                }, n(), a())) : Q.a.createElement(ee.a.Row, null, Q.a.createElement(ee.a.Cell, {
                    placement: "first",
                    colSpan: 2,
                    offset: I,
                    "data-section-name": c
                }, n(), a())), b && Q.a.createElement(ee.a.Row, null, Q.a.createElement(ee.a.Cell, {
                    placement: "first",
                    colSpan: 2,
                    offset: I,
                    "data-section-name": c
                }, Q.a.createElement(B, {
                    className: re()(Je.textarea, D[c] && Je[D[c]]),
                    property: b,
                    disabled: te,
                    onFocus: function(e) {
                        e.target.select()
                    },
                    name: "text-input"
                }))), (v || g) && Q.a.createElement(ee.a.Row, null, Q.a.createElement(ee.a.Cell, {
                    placement: "first",
                    verticalAlign: "adaptive",
                    offset: I,
                    "data-section-name": c
                }, Q.a.createElement(r, null, j)), Q.a.createElement(ee.a.Cell, {
                    placement: "last",
                    verticalAlign: "adaptive",
                    "data-section-name": c
                }, Q.a.createElement(y, {
                    breakPoint: "Small"
                }, void 0 !== U && void 0 !== T && Q.a.createElement(ce.a, {
                    className: Je.dropdown,
                    menuClassName: Je.dropdownMenu,
                    disabled: te,
                    value: U,
                    items: T.map(Ze),
                    onChange: X,
                    "data-name": "alignment-vertical-select"
                }), void 0 !== Y && void 0 !== x && Q.a.createElement(ce.a, {
                    className: Je.dropdown,
                    menuClassName: Je.dropdownMenu,
                    disabled: te,
                    value: Y,
                    items: x.map(Ze),
                    onChange: q,
                    "data-name": "alignment-horizontal-select"
                })))), i(R, _, w, !!_ && !J), i(F, N, C, !!N && !Z, S, z), k && Q.a.createElement(o, {
                    id: c + "Wrap",
                    offset: I,
                    checked: k,
                    title: A,
                    disabled: e.disabled || L
                }))
            }

            function A(e) {
                var t = e.definition,
                    n = t.properties,
                    a = n.x,
                    r = n.y,
                    i = n.disabled,
                    o = t.id,
                    l = t.minX,
                    c = t.maxX,
                    s = t.stepX,
                    u = t.minY,
                    d = t.maxY,
                    m = t.stepY,
                    f = t.title,
                    h = t.typeX,
                    b = t.typeY,
                    v = e.offset,
                    g = i && i.value() || e.disabled,
                    E = Re({
                        watchedValue: l,
                        defaultValue: void 0
                    }),
                    _ = Re({
                        watchedValue: c,
                        defaultValue: void 0
                    }),
                    w = Re({
                        watchedValue: s,
                        defaultValue: void 0
                    }),
                    N = Re({
                        watchedValue: u,
                        defaultValue: void 0
                    }),
                    C = Re({
                        watchedValue: d,
                        defaultValue: void 0
                    }),
                    S = Re({
                        watchedValue: m,
                        defaultValue: void 0
                    });
                return Q.a.createElement(ee.a.Row, null, Q.a.createElement(ee.a.Cell, {
                    verticalAlign: "adaptive",
                    placement: "first",
                    offset: v,
                    "data-section-name": o
                }, Q.a.createElement("span", {
                    className: $e.coordinates
                }, f)), (a || r) && Q.a.createElement(ee.a.Cell, {
                    placement: "last",
                    offset: v,
                    "data-section-name": o
                }, Q.a.createElement(y, {
                    breakPoint: "Medium"
                }, r && Q.a.createElement(p, {
                    className: $e.input,
                    property: r,
                    min: N,
                    max: C,
                    step: S,
                    disabled: g,
                    name: "y-input",
                    mode: void 0 !== b ? Pe[b] : "integer"
                }), a && Q.a.createElement(p, {
                    className: $e.input,
                    property: a,
                    min: E,
                    max: _,
                    step: w,
                    disabled: g,
                    name: "x-input",
                    mode: void 0 !== h ? Pe[h] : "integer"
                }))))
            }

            function I(e) {
                var t = e.definition,
                    n = t.id,
                    a = t.properties,
                    i = a.checked,
                    l = a.option,
                    c = a.disabled,
                    s = t.title,
                    u = t.options,
                    d = e.offset,
                    p = $({
                        property: i,
                        defaultValue: !0
                    })[0],
                    m = $({
                        property: c,
                        defaultValue: !1
                    })[0],
                    f = Object(K.useContext)(De.b),
                    h = e.disabled || !p;
                return Q.a.createElement(o, {
                    id: n,
                    offset: d,
                    checked: i,
                    title: s,
                    disabled: e.disabled || m
                }, Q.a.createElement(r, null, Q.a.createElement(V, {
                    className: re()(et.dropdown, f[n] && et[f[n]]),
                    menuClassName: re()(et.dropdownMenu, f[n] && et[f[n]]),
                    disabled: h,
                    property: l,
                    options: u,
                    "data-name": "options-dropdown"
                })))
            }

            function D(e) {
                function t(e, t) {
                    V(Math.round(e)), F(Math.round(t))
                }

                function n() {
                    A.flushed || (j(), B(), A.flushed = !0)
                }
                var a = e.definition,
                    i = a.id,
                    l = a.properties,
                    c = l.checked,
                    s = l.disabled,
                    u = l.from,
                    p = l.to,
                    f = a.title,
                    h = a.max,
                    b = a.min,
                    v = e.offset,
                    g = $({
                        property: c,
                        defaultValue: !0
                    })[0],
                    E = $({
                        property: s,
                        defaultValue: !1
                    })[0],
                    _ = Re({
                        watchedValue: b,
                        defaultValue: void 0
                    }),
                    w = Re({
                        watchedValue: h,
                        defaultValue: void 0
                    }),
                    N = $({
                        property: u
                    }),
                    C = N[0],
                    S = N[1],
                    k = d(C, S),
                    O = k[0],
                    V = k[1],
                    j = k[2],
                    x = $({
                        property: p
                    }),
                    M = x[0],
                    T = x[1],
                    P = d(M, T),
                    R = P[0],
                    F = P[1],
                    B = P[2],
                    z = e.disabled || !g,
                    A = {
                        flushed: !1
                    };
                return Q.a.createElement(o, {
                    id: i,
                    offset: v,
                    checked: c,
                    title: f,
                    disabled: e.disabled || E
                }, Q.a.createElement(r, {
                    className: it.range
                }, _ && w ? Q.a.createElement(rt.a, {
                    rule: "screen and (max-width: 460px)"
                }, function(e) {
                    return Q.a.createElement(y, {
                        breakPoint: "Medium"
                    }, Q.a.createElement(Q.a.Fragment, null, Q.a.createElement("span", {
                        className: it.valueInput
                    }, Q.a.createElement(m, {
                        className: it.input,
                        sharedBuffer: k,
                        min: _,
                        max: R,
                        step: 1,
                        disabled: z,
                        name: "from-input",
                        mode: "integer"
                    }), e ? Q.a.createElement("span", {
                        className: it.rangeSlider
                    }, "—") : Q.a.createElement(at, {
                        className: it.rangeSlider,
                        from: O,
                        to: R,
                        min: _,
                        max: w,
                        onChange: t,
                        onCommit: n,
                        disabled: z
                    }))), Q.a.createElement(Q.a.Fragment, null, Q.a.createElement("span", {
                        className: it.valueInput
                    }, Q.a.createElement(m, {
                        className: it.input,
                        sharedBuffer: P,
                        min: O,
                        max: w,
                        step: 1,
                        disabled: z,
                        name: "to-input",
                        mode: "integer"
                    }))))
                }) : null))
            }

            function W(e) {
                return Q.a.createElement(ee.a.Row, null, Q.a.createElement(ee.a.Cell, {
                    className: ot.titleWrap,
                    placement: "first",
                    verticalAlign: "adaptive",
                    colSpan: 2,
                    "data-section-name": e.name,
                    checkableTitle: !0
                }, Q.a.createElement(i, {
                    title: e.title,
                    name: "is-enabled-" + e.name
                })))
            }

            function L(e) {
                var t = e.definitions,
                    n = e.name,
                    a = e.offset;
                return Q.a.createElement(ee.a.Row, null, Q.a.createElement(ee.a.Cell, {
                    className: re()(lt.cell, lt.fragmentCell),
                    offset: a,
                    placement: "first",
                    verticalAlign: "adaptive",
                    colSpan: 2,
                    "data-section-name": n,
                    checkableTitle: !0
                }, t.map(function(e) {
                    return Q.a.createElement("div", {
                        className: lt.item,
                        key: e.id,
                        "data-section-name": e.id
                    }, Q.a.createElement(U, {
                        definition: e
                    }))
                })))
            }

            function H(e) {
                var t = e.definition,
                    n = e.offset;
                return Q.a.createElement(ee.a.Row, null, Q.a.createElement(ee.a.Cell, {
                    className: lt.cell,
                    offset: n,
                    placement: "first",
                    verticalAlign: "adaptive",
                    colSpan: 2,
                    checkableTitle: !0
                }, Q.a.createElement(U, {
                    definition: t
                })))
            }

            function U(e) {
                var t = e.definition,
                    n = t.id,
                    a = t.properties,
                    r = a.disabled,
                    o = a.checked,
                    l = a.color,
                    s = a.level,
                    u = a.width,
                    d = a.style,
                    m = t.title,
                    f = t.widthValues,
                    h = t.styleValues,
                    b = $({
                        property: o,
                        defaultValue: !0
                    })[0],
                    v = $({
                        property: r,
                        defaultValue: !1
                    })[0],
                    g = v || !b;
                return Q.a.createElement(Q.a.Fragment, null, Q.a.createElement(i, {
                    name: "is-enabled-" + n,
                    className: re()(m && lt.withTitle),
                    title: m && Q.a.createElement("span", {
                        className: lt.title
                    }, m),
                    property: o,
                    disabled: v
                }), s && Q.a.createElement(p, {
                    className: re()(lt.input, lt.control),
                    property: s,
                    disabled: g
                }), l && Q.a.createElement(E, {
                    className: lt.control,
                    disabled: g,
                    color: l,
                    thickness: u,
                    thicknessItems: f
                }), d && Q.a.createElement(c, {
                    className: lt.control,
                    property: d,
                    disabled: g,
                    allowedLineStyles: h
                }))
            }

            function X(e) {
                var t = e.definition,
                    n = t.id,
                    a = t.properties,
                    r = a.option1,
                    i = a.option2,
                    l = a.checked,
                    c = a.disabled,
                    s = t.title,
                    u = t.optionsItems1,
                    d = t.optionsItems2,
                    p = e.offset,
                    m = $({
                        property: l,
                        defaultValue: !0
                    })[0],
                    f = $({
                        property: c,
                        defaultValue: !1
                    })[0],
                    h = e.disabled || !m;
                return Q.a.createElement(o, {
                    id: n,
                    offset: p,
                    checked: l,
                    title: s,
                    disabled: e.disabled || f
                }, Q.a.createElement(y, {
                    className: ct.twoOptions
                }, Q.a.createElement(V, {
                    className: ct.dropdown,
                    menuClassName: ct.menu,
                    property: r,
                    disabled: h,
                    options: u,
                    "data-name": "two-options-dropdown-1"
                }), Q.a.createElement(V, {
                    className: ct.dropdown,
                    menuClassName: ct.menu,
                    property: i,
                    disabled: h,
                    options: d,
                    "data-name": "two-options-dropdown-2"
                })))
            }

            function G(e) {
                var t, n, a = e.definition;
                if (function(e) {
                        Object(K.useEffect)(function() {
                            if (void 0 !== e) {
                                var t = Object(q.__assign)({}, e.properties);
                                return Object.entries(t).forEach(function(n) {
                                        var a = n[0],
                                            r = n[1];
                                        void 0 !== r && r.subscribe(t, function() {
                                            return Z.a.logNormal('Property "' + a + '" in definition "' + e.id + '" was updated to value "' + r.value() + '"')
                                        })
                                    }),
                                    function() {
                                        Object.entries(t).forEach(function(e) {
                                            var n = e[1];
                                            void 0 !== n && n.unsubscribeAll(t)
                                        })
                                    }
                            }
                        }, [e])
                    }(Object(J.z)(a) ? void 0 : a), Object(J.z)(a)) return t = a.definitions, Q.a.createElement(K.Fragment, null, a.title && Q.a.createElement(W, {
                    title: a.title,
                    name: a.id
                }), t && (n = t.value(), n.reduce(function(e, t) {
                    if (Object(J.z)(t) || "leveledLine" !== t.propType) e.push(t);
                    else {
                        var n = e[e.length - 1];
                        Array.isArray(n) ? n.push(t) : e.push([t])
                    }
                    return e
                }, [])).map(function(t) {
                    return Array.isArray(t) ? Q.a.createElement(L, {
                        key: t[0].id,
                        name: a.id,
                        definitions: t
                    }) : Q.a.createElement(G, Object(q.__assign)({
                        key: t.id
                    }, e, {
                        definition: t
                    }))
                }), "general" === a.groupType && Q.a.createElement(ee.a.GroupSeparator, {
                    size: 1
                }));
                switch (a.propType) {
                    case "line":
                        return Q.a.createElement(w, Object(q.__assign)({}, e, {
                            definition: a
                        }));
                    case "checkable":
                        return Q.a.createElement(l, Object(q.__assign)({}, e, {
                            definition: a
                        }));
                    case "color":
                        return Q.a.createElement(N, Object(q.__assign)({}, e, {
                            definition: a
                        }));
                    case "transparency":
                        return Q.a.createElement(k, Object(q.__assign)({}, e, {
                            definition: a
                        }));
                    case "twoColors":
                        return Q.a.createElement(O, Object(q.__assign)({}, e, {
                            definition: a
                        }));
                    case "number":
                        return Q.a.createElement(j, Object(q.__assign)({}, e, {
                            definition: a
                        }));
                    case "text":
                        return Q.a.createElement(z, Object(q.__assign)({}, e, {
                            definition: a
                        }));
                    case "checkableSet":
                        return Q.a.createElement(x, Object(q.__assign)({}, e, {
                            definition: a
                        }));
                    case "options":
                        return Q.a.createElement(I, Object(q.__assign)({}, e, {
                            definition: a
                        }));
                    case "range":
                        return Q.a.createElement(D, Object(q.__assign)({}, e, {
                            definition: a
                        }));
                    case "coordinates":
                        return Q.a.createElement(A, Object(q.__assign)({}, e, {
                            definition: a
                        }));
                    case "twoOptions":
                        return Q.a.createElement(X, Object(q.__assign)({}, e, {
                            definition: a
                        }));
                    case "leveledLine":
                        return Q.a.createElement(H, Object(q.__assign)({}, e, {
                            definition: a
                        }));
                    default:
                        return null
                }
            }
            var Y, q = n("mrSG"),
                K = n("q1tI"),
                Q = n.n(K),
                J = n("HSjo"),
                Z = n("yqnI"),
                $ = function(e) {
                    var t = "property" in e ? e.property : void 0,
                        n = "defaultValue" in e ? e.defaultValue : e.property.value(),
                        a = Object(K.useState)(t ? t.value() : n),
                        r = a[0],
                        i = a[1];
                    return Object(K.useEffect)(function() {
                        if (t) {
                            var n = {};
                            return i(t.value()), t.subscribe(n, function(t) {
                                    var n = t.value();
                                    e.handler && e.handler(n), i(n)
                                }),
                                function() {
                                    return t.unsubscribeAll(n)
                                }
                        }
                        return function() {}
                    }, [t]), [r, function(e) {
                        if (void 0 !== t) {
                            var n = t.value();
                            Z.a.logNormal('Changing property value from "' + n + '" to "' + e + '"'), t.setValue(e)
                        }
                    }]
                },
                ee = n("Q+1u"),
                te = n("qFKp"),
                ne = n("dWaX"),
                ae = n("TSYQ"),
                re = n.n(ae),
                ie = n("eG6P"),
                oe = n("vxCt"),
                le = n("KacW"),
                ce = n("H172"),
                se = n("kJwE"),
                ue = [1, 2, 3, 4],
                de = n("nc0P"),
                pe = n("Eyy1"),
                me = n("/3z9"),
                fe = n("WboT"),
                he = n("Hr11"),
                be = n("zXvd"),
                ve = {
                    mode: "float",
                    min: -Number.MAX_VALUE,
                    max: Number.MAX_VALUE,
                    step: 1,
                    precision: 0,
                    inheritPrecisionFromStep: !0
                },
                ge = function(e) {
                    function t(t) {
                        var n, a = e.call(this, t) || this;
                        return a._selection = null, a._restoreSelection = !1, a._input = null, a._handleSelectionChange = function() {
                            a._restoreSelection || document.activeElement !== Object(pe.ensureNotNull)(a._input) || a._saveSelection(Object(pe.ensureNotNull)(a._input))
                        }, a._handleInputReference = function(e) {
                            a._input = e, a.props.inputReference && a.props.inputReference(e)
                        }, a._onFocus = function(e) {
                            a._saveSelection(Object(pe.ensureNotNull)(a._input)), a.setState({
                                focused: !0
                            }), a.props.onFocus && a.props.onFocus(e)
                        }, a._onBlur = function(e) {
                            a._selection = null, a.setState({
                                displayValue: f(a.props, a.props.value, h(a.props)),
                                focused: !1
                            }), a.props.onBlur && a.props.onBlur(e)
                        }, a._onValueChange = function(e) {
                            var t, n, r = e.currentTarget,
                                i = r.value,
                                o = function(e, t, n) {
                                    switch (n) {
                                        case "integer":
                                            return Ee.test(t) ? t : e;
                                        case "float":
                                            return t = t.replace(/,/g, "."), _e.test(t) ? t : e
                                    }
                                }(a.state.displayValue, i, a.props.mode),
                                l = v(o),
                                c = a._checkValueBoundaries(l);
                            a.setState({
                                displayValue: o
                            }), o !== i && (t = a.state.displayValue, n = (n = o).replace(/,/g, "."), (t = t.replace(/,/g, ".")).includes(".") || !n.includes(".")) ? (a._restoreSelection = !0, a.forceUpdate()) : a._saveSelection(r), c.value && f(a.props, l) === o && a.props.onValueChange(l, "input")
                        }, a._onValueByStepChange = function(e) {
                            var t, n, r, i, o, l = a.props,
                                c = l.roundByStep,
                                s = void 0 === c || c,
                                u = l.step,
                                d = void 0 === u ? 1 : u,
                                p = v(a.state.displayValue);
                            isNaN(p) || (t = new de.Big(p), n = new de.Big(d), r = t.mod(n), i = t.plus(e * d), !r.eq(0) && s && (i = i.plus((e > 0 ? 0 : 1) * d).minus(r)), o = Number(i), a._checkValueBoundaries(o).value && (a.setState({
                                displayValue: f(a.props, o, h(a.props))
                            }), a.props.onValueChange(o, "step")))
                        }, n = g(a.props.value), a.state = {
                            value: n,
                            displayValue: f(a.props, n, h(a.props)),
                            focused: !1,
                            valueHash: a.props.valueHash
                        }, a
                    }
                    return Object(q.__extends)(t, e), t.prototype.componentDidMount = function() {
                        document.addEventListener("selectionchange", this._handleSelectionChange)
                    }, t.prototype.componentWillUnmount = function() {
                        document.removeEventListener("selectionchange", this._handleSelectionChange)
                    }, t.prototype.componentDidUpdate = function() {
                        var e, t, n, a = Object(pe.ensureNotNull)(this._input),
                            r = this._selection;
                        null !== r && this._restoreSelection && document.activeElement === a && (e = r.start, t = r.end, n = r.direction, a.setSelectionRange(e, t, n)), this._restoreSelection = !1
                    }, t.prototype.render = function() {
                        return Q.a.createElement(fe.a, {
                            inputMode: this.props.inputMode,
                            name: this.props.name,
                            borderStyle: "thick",
                            fontSizeStyle: "medium",
                            value: this.state.displayValue,
                            className: this.props.className,
                            placeholder: this.props.placeholder,
                            disabled: this.props.disabled,
                            onValueChange: this._onValueChange,
                            onValueByStepChange: this._onValueByStepChange,
                            containerReference: this.props.containerReference,
                            inputReference: this._handleInputReference,
                            onClick: this.props.onClick,
                            onFocus: this._onFocus,
                            onBlur: this._onBlur,
                            onKeyDown: this.props.onKeyDown
                        })
                    }, t.prototype.getClampedValue = function() {
                        var e = this.props,
                            t = e.min,
                            n = e.max,
                            a = v(this.state.displayValue);
                        return isNaN(a) ? null : Object(he.clamp)(a, t, n)
                    }, t.getDerivedStateFromProps = function(e, t) {
                        var n = e.valueHash,
                            a = g(e.value);
                        return t.value !== a || t.valueHash !== n ? {
                            value: a,
                            valueHash: n,
                            displayValue: f(0, a, t.focused && t.valueHash === n ? void 0 : h(e))
                        } : null
                    }, t.prototype._saveSelection = function(e) {
                        var t = e.selectionStart,
                            n = e.selectionEnd,
                            a = e.selectionDirection;
                        null !== t && null !== n && null !== a && (this._selection = {
                            start: t,
                            end: n,
                            direction: a
                        })
                    }, t.prototype._checkValueBoundaries = function(e) {
                        var t = this.props,
                            n = t.min,
                            a = t.max,
                            r = function(e, t, n) {
                                var a = e >= t,
                                    r = e <= n;
                                return {
                                    passMin: a,
                                    passMax: r,
                                    pass: a && r,
                                    clamped: Object(he.clamp)(e, t, n)
                                }
                            }(e, n, a);
                        return {
                            value: r.pass
                        }
                    }, t.defaultProps = ve, t
                }(Q.a.PureComponent),
                Ee = /^\-?[0-9]*$/,
                _e = /^(\-?([0-9]+\.?[0-9]*)|(\-?[0-9]*))$/,
                ye = n("eJTA"),
                we = n("7MId"),
                Ne = n("Tmoa"),
                Ce = (n("YFKU"), n("a7Ha")),
                Se = n("CHgb"),
                ke = n("QpNh"),
                Oe = n("FIOl"),
                Ve = n("jAqK"),
                je = n("8XTa"),
                xe = [{
                    type: Ce.LineEnd.Normal,
                    icon: Oe,
                    label: window.t("Normal")
                }, {
                    type: Ce.LineEnd.Arrow,
                    icon: Ve,
                    label: window.t("Arrow")
                }],
                Me = function(e) {
                    function t(t) {
                        var n = e.call(this, t) || this;
                        return n._items = [], n._items = xe.map(function(e) {
                            return {
                                value: e.type,
                                selectedContent: Q.a.createElement(Se.a, {
                                    icon: e.icon
                                }),
                                content: Q.a.createElement(Se.b, {
                                    icon: e.icon,
                                    iconClassName: re()(t.isRight && je.right),
                                    label: e.label
                                })
                            }
                        }), n
                    }
                    return Object(q.__extends)(t, e), t.prototype.render = function() {
                        var e = this.props,
                            t = e.lineEnd,
                            n = e.className,
                            a = e.lineEndChange,
                            r = e.isRight,
                            i = e.disabled;
                        return Q.a.createElement(Se.c, Object(q.__assign)({
                            disabled: i,
                            className: re()(je.lineEndSelect, r && je.right, n),
                            items: this._items,
                            value: t,
                            onChange: a,
                            hideArrowButton: !0
                        }, Object(ke.a)(this.props)))
                    }, t
                }(Q.a.PureComponent),
                Te = n("6w4h"),
                Pe = ((Y = {})[1] = "float", Y[0] = "integer", Y),
                Re = function(e) {
                    var t = "watchedValue" in e ? e.watchedValue : void 0,
                        n = "defaultValue" in e ? e.defaultValue : e.watchedValue.value(),
                        a = Object(K.useState)(t ? t.value() : n),
                        r = a[0],
                        i = a[1];
                    return Object(K.useEffect)(function() {
                        if (t) {
                            i(t.value());
                            var e = function(e) {
                                return i(e)
                            };
                            return t.subscribe(e),
                                function() {
                                    return t.unsubscribe(e)
                                }
                        }
                        return function() {}
                    }, [t]), r
                },
                Fe = n("eU7S"),
                Be = n("U1eG"),
                ze = n("6Kf3"),
                Ae = n("lB1i"),
                Ie = n("oWdB"),
                De = n("ybVX"),
                We = n("gla1"),
                Le = n("ZRxn"),
                He = n("UXjO"),
                Ue = n("jjrI"),
                Xe = n("aw5J"),
                Ge = n("Wvr1"),
                Ye = n("k+zC"),
                qe = n("jggR"),
                Ke = n("rRJX"),
                Qe = n("4Fxa"),
                Je = n("CaTF"),
                Ze = function(e) {
                    return {
                        content: e.title,
                        title: e.title,
                        value: e.value
                    }
                },
                $e = n("aSdR"),
                et = n("9gev"),
                tt = n("Ialn"),
                nt = n("G7lD"),
                at = function(e) {
                    function t(t) {
                        var n = e.call(this, t) || this;
                        return n._container = null, n._pointer = null, n._rafPosition = null, n._rafDragStop = null, n._refContainer = function(e) {
                            n._container = e
                        }, n._refPointer = function(e) {
                            n._pointer = e
                        }, n._handlePosition = function(e) {
                            null !== n._rafPosition || n.props.disabled || (n._rafPosition = requestAnimationFrame(function() {
                                var t = n.props,
                                    a = t.from,
                                    r = t.to,
                                    i = t.min,
                                    o = t.max,
                                    l = n._getNewPosition(e),
                                    c = n._detectPointerMode(e),
                                    s = 1 === c,
                                    u = s ? Object(he.clamp)(l, i, r) : a,
                                    d = s ? r : Object(he.clamp)(l, a, o);
                                u <= d && n._handleChange(u, d), n._rafPosition = null
                            }))
                        }, n._handleDragStop = function() {
                            null !== n._rafDragStop || n.props.disabled || (n._rafDragStop = requestAnimationFrame(function() {
                                n.setState({
                                    pointerDragMode: 0
                                }), n._rafDragStop = null, n.props.onCommit()
                            }))
                        }, n._onSliderClick = function(e) {
                            te.CheckMobile.any() || (n._handlePosition(e.nativeEvent), n._dragSubscribe())
                        }, n._mouseUp = function(e) {
                            n._dragUnsubscribe(), n._handlePosition(e), n._handleDragStop()
                        }, n._mouseMove = function(e) {
                            n._handlePosition(e)
                        }, n._onTouchStart = function(e) {
                            n._handlePosition(e.nativeEvent.touches[0])
                        }, n._handleTouch = function(e) {
                            n._handlePosition(e.nativeEvent.touches[0])
                        }, n._handleTouchEnd = function() {
                            n._handleDragStop()
                        }, n.state = {
                            pointerDragMode: 0
                        }, n
                    }
                    return Object(q.__extends)(t, e), t.prototype.componentWillUnmount = function() {
                        null !== this._rafPosition && (cancelAnimationFrame(this._rafPosition), this._rafPosition = null), null !== this._rafDragStop && (cancelAnimationFrame(this._rafDragStop), this._rafDragStop = null), this._dragUnsubscribe()
                    }, t.prototype.render = function() {
                        var e, t, n, a = this.props,
                            r = a.className,
                            i = a.disabled,
                            o = a.from,
                            l = a.to,
                            c = a.min,
                            s = a.max,
                            u = this.state.pointerDragMode,
                            d = 0 !== u,
                            p = s - c,
                            m = (o - c) / p,
                            f = (l - c) / p,
                            h = Object(tt.isRtl)() ? "right" : "left";
                        return K.createElement("div", {
                            className: ae(r, nt.range, i && nt.disabled)
                        }, K.createElement("div", {
                            className: nt.rangeSlider,
                            ref: this._refContainer,
                            onMouseDown: this._onSliderClick,
                            onTouchStart: this._onTouchStart,
                            onTouchMove: this._handleTouch,
                            onTouchEnd: this._handleTouchEnd
                        }, K.createElement("div", {
                            className: nt.rangeSliderMiddleWrap
                        }, K.createElement("div", {
                            className: ae(nt.rangeSliderMiddle, d && nt.dragged),
                            style: (e = {}, e[h] = 100 * m + "%", e.width = 100 * (f - m) + "%", e)
                        })), K.createElement("div", {
                            className: nt.rangePointerWrap
                        }, K.createElement("div", {
                            className: ae(nt.pointer, d && nt.dragged),
                            style: (t = {}, t[h] = 100 * m + "%", t),
                            ref: this._refPointer
                        })), K.createElement("div", {
                            className: nt.rangePointerWrap
                        }, K.createElement("div", {
                            className: ae(nt.pointer, d && nt.dragged),
                            style: (n = {}, n[h] = 100 * f + "%", n)
                        }))))
                    }, t.prototype._dragSubscribe = function() {
                        var e = Object(pe.ensureNotNull)(this._container).ownerDocument;
                        e && (e.addEventListener("mouseup", this._mouseUp), e.addEventListener("mousemove", this._mouseMove))
                    }, t.prototype._dragUnsubscribe = function() {
                        var e = Object(pe.ensureNotNull)(this._container).ownerDocument;
                        e && (e.removeEventListener("mousemove", this._mouseMove), e.removeEventListener("mouseup", this._mouseUp))
                    }, t.prototype._getNewPosition = function(e) {
                        var t = this.props,
                            n = t.min,
                            a = t.max,
                            r = a - n,
                            i = Object(pe.ensureNotNull)(this._container),
                            o = Object(pe.ensureNotNull)(this._pointer),
                            l = i.getBoundingClientRect(),
                            c = o.offsetWidth,
                            s = e.clientX - c / 2 - l.left;
                        return Object(tt.isRtl)() && (s = l.width - s - c), Object(he.clamp)(s / (l.width - c), 0, 1) * r + n
                    }, t.prototype._detectPointerMode = function(e) {
                        var t, n, a, r, i = this.props,
                            o = i.from,
                            l = i.to,
                            c = this.state.pointerDragMode;
                        return 0 !== c ? c : (t = this._getNewPosition(e), r = (n = Math.abs(o - t)) === (a = Math.abs(l - t)) ? t < o ? 1 : 2 : n < a ? 1 : 2, this.setState({
                            pointerDragMode: r
                        }), r)
                    }, t.prototype._handleChange = function(e, t) {
                        var n = this.props,
                            a = n.from,
                            r = n.to,
                            i = n.onChange;
                        e === a && t === r || i(e, t)
                    }, t
                }(K.PureComponent),
                rt = n("/KDZ"),
                it = n("7EmB"),
                ot = n("Q40t"),
                lt = n("EJl2"),
                ct = n("ZcEB");
            n.d(t, "a", function() {
                return G
            })
        },
        eG6P: function(e, t, n) {
            e.exports = {
                wrap: "wrap-3VxI_YR4"
            }
        },
        eU7S: function(e, t, n) {
            e.exports = {
                line: "line-Xef4M09H",
                control: "control-3967I_nS",
                valueInput: "valueInput-1ujFKjiy",
                valueUnit: "valueUnit-WuH55OtL",
                input: "input-3Sw_tvuz"
            }
        },
        gla1: function(e, t, n) {
            "use strict";
            var a, r;
            n.d(t, "a", function() {
                return r
            }), a = n("q1tI"), r = function() {
                return Object(a.useReducer)(function(e, t) {
                    return e + 1
                }, 0)[1]
            }
        },
        "i/MG": function(e, t, n) {
            "use strict";
            var a, r, i, o, l, c, s;
            n.d(t, "a", function() {
                return s
            }), a = n("mrSG"), n("YFKU"), r = n("q1tI"), i = n("TSYQ"), o = n("kXJy"), l = n("+l9v"), c = {
                remove: window.t("Remove")
            }, s = function(e) {
                function t() {
                    var t = null !== e && e.apply(this, arguments) || this;
                    return t._handleClick = function(e) {
                        var n = t.props,
                            a = n.onClick,
                            r = n.onClickArg;
                        a && a(r, e)
                    }, t
                }
                return Object(a.__extends)(t, e), t.prototype.render = function() {
                    return r.createElement("span", {
                        className: i(o.button, "apply-common-tooltip", this.props.hidden && o.hidden),
                        dangerouslySetInnerHTML: {
                            __html: l
                        },
                        onClick: this._handleClick,
                        title: c.remove,
                        "data-name": "remove-button"
                    })
                }, t
            }(r.PureComponent)
        },
        jAqK: function(e, t) {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M4.5 13.5H24m-19.5 0L8 17m-3.5-3.5L8 10"/></svg>'
        },
        jggR: function(e, t, n) {
            e.exports = {
                container: "container-2IsTVQ49",
                focused: "focused-1QCDvHCH",
                readonly: "readonly-3TW7INT8",
                disabled: "disabled-Ju2phm9i",
                "size-medium": "size-medium-2lM1uGoO",
                "size-large": "size-large-1NHR4lnE",
                "font-size-medium": "font-size-medium-3lwViqM8",
                "font-size-large": "font-size-large-uTIroj7p",
                "border-none": "border-none-2LzWNqL7",
                shadow: "shadow-AN9BmmG5",
                "border-thin": "border-thin-2QjYg4o3",
                "border-thick": "border-thick-3XUkSewU",
                "intent-default": "intent-default-1A7eWGEJ",
                "intent-success": "intent-success-1Oz2EYaq",
                "intent-warning": "intent-warning-2CIKi-Sg",
                "intent-danger": "intent-danger-34bo52Yx",
                "intent-primary": "intent-primary-30cIvmgZ",
                "corner-top-left": "corner-top-left-3jqic47X",
                "corner-top-right": "corner-top-right-YZ3WAu2k",
                "corner-bottom-right": "corner-bottom-right-3_DA5L_W",
                "corner-bottom-left": "corner-bottom-left-3lFAslf6",
                textarea: "textarea-bk9MQutx"
            }
        },
        kJwE: function(e, t, n) {
            e.exports = {
                lineWidthSelect: "lineWidthSelect-3ziEuHcz",
                bar: "bar-37_AfcZG",
                isActive: "isActive-dohf9HfR",
                item: "item-2zVrXM_1"
            }
        },
        kXJy: function(e, t, n) {
            e.exports = {
                button: "button-1scLo53s",
                hidden: "hidden-2GRQzIQ1"
            }
        },
        lB1i: function(e, t, n) {
            e.exports = {
                wrap: "wrap-K_N9jM1e",
                disabled: "disabled-2QK47L8c"
            }
        },
        oWdB: function(e, t, n) {
            e.exports = {
                twoColors: "twoColors-iyrZVlk4",
                colorPicker: "colorPicker-3hYQ60NL"
            }
        },
        rRJX: function(e, t) {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M14 21h-3a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1h3c2 0 4 1 4 3 0 1 0 2-1.5 3 1.5.5 2.5 2 2.5 4 0 2.75-2.638 4-5 4zM12 9l.004 3c.39.026.82 0 1.25 0C14.908 12 16 11.743 16 10.5c0-1.1-.996-1.5-2.5-1.5-.397 0-.927-.033-1.5 0zm0 5v5h1.5c1.5 0 3.5-.5 3.5-2.5S15 14 13.5 14c-.5 0-.895-.02-1.5 0z"/></svg>'
        },
        vxCt: function(e, t, n) {
            e.exports = {
                checkbox: "checkbox-1So8p7GP",
                title: "title-1uAaOORo"
            }
        },
        ybVX: function(e, t, n) {
            "use strict";
            var a, r, i, o;
            n.d(t, "b", function() {
                return i
            }), n.d(t, "a", function() {
                return o
            }), a = n("q1tI"), i = (r = n.n(a)).a.createContext({}), o = r.a.createContext({})
        },
        yqnI: function(e, t, n) {
            "use strict";
            var a, r;
            n.d(t, "a", function() {
                return r
            }), a = n("uOxu"), r = Object(a.getLogger)("Platform.GUI.PropertyDefinitionTrace")
        }
    }
]);