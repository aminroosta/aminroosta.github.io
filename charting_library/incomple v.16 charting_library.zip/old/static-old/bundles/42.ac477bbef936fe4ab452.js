(window.webpackJsonp = window.webpackJsonp || []).push([
    [42], {
        "2dtg": function(o, e) {
            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><g fill="currentColor" fill-rule="evenodd"><path fill-rule="nonzero" d="M23.002 23C23 23 23 18.003 23 18.003L15.998 18C16 18 16 22.997 16 22.997l7.002.003zM15 18.003A1 1 0 0 1 15.998 17h7.004c.551 0 .998.438.998 1.003v4.994A1 1 0 0 1 23.002 24h-7.004A.993.993 0 0 1 15 22.997v-4.994z"/><path d="M19 20h1v2h-1z"/><path fill-rule="nonzero" d="M22 14.5a2.5 2.5 0 0 0-5 0v3h1v-3a1.5 1.5 0 0 1 3 0v.5h1v-.5z"/><g fill-rule="nonzero"><path d="M3 14.707A1 1 0 0 1 3.293 14L14.439 2.854a1.5 1.5 0 0 1 2.122 0l2.585 2.585a1.5 1.5 0 0 1 0 2.122L8 18.707a1 1 0 0 1-.707.293H4a1 1 0 0 1-1-1v-3.293zm1 0V18h3.293L18.439 6.854a.5.5 0 0 0 0-.708l-2.585-2.585a.5.5 0 0 0-.708 0L4 14.707z"/><path d="M13.146 4.854l4 4 .708-.708-4-4zm-9 9l4 4 .708-.708-4-4z"/><path d="M15.146 6.146l-9 9 .708.708 9-9z"/></g></g></svg>'
        },
        "2lje": function(o, e) {
            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 29 31" width="29" height="31"><g fill="currentColor" fill-rule="nonzero"><path d="M15.3 22l8.187-8.187c.394-.394.395-1.028.004-1.418l-4.243-4.243c-.394-.394-1.019-.395-1.407-.006l-11.325 11.325c-.383.383-.383 1.018.007 1.407l1.121 1.121h7.656zm-9.484-.414c-.781-.781-.779-2.049-.007-2.821l11.325-11.325c.777-.777 2.035-.78 2.821.006l4.243 4.243c.781.781.78 2.048-.004 2.832l-8.48 8.48h-8.484l-1.414-1.414z"/><path d="M13.011 22.999h7.999v-1h-7.999zM13.501 11.294l6.717 6.717.707-.707-6.717-6.717z"/></g></svg>'
        },
        "3s8f": function(o, e) {
            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><g fill="currentColor" fill-rule="evenodd"><path fill-rule="nonzero" d="M14 10a2 2 0 0 0-2 2v11H6V12c0-4.416 3.584-8 8-8s8 3.584 8 8v11h-6V12a2 2 0 0 0-2-2zm-3 2a3 3 0 0 1 6 0v10h4V12c0-3.864-3.136-7-7-7s-7 3.136-7 7v10h4V12z"/><path d="M6.5 18h5v1h-5zm10 0h5v1h-5z"/></g></svg>'
        },
        "43BO": function(o, e) {
            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="m6 13a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2m1 0a2 2 0 0 0 1 1h12a2 2 0 0 0 1-1v-9a2 2 0 0 0-1-1H8a2 2 0 0 0-1 1m6 5a1 1 0 0 1 2 0v2a1 1 0 0 1-2 0m-3-9V8a1 1 0 0 1 8 0v3h-1V8a1 1 0 0 0-6 0v3"/></svg>'
        },
        "6oLA": function(o, e) {
            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><g fill="currentColor"><path fill-rule="nonzero" d="M4.034 14.18l-.07-.18.07-.18c1.535-3.975 5.645-6.82 9.966-6.82 4.32 0 8.431 2.845 9.966 6.82l.07.18-.07.18c-1.535 3.975-5.646 6.82-9.966 6.82-4.321 0-8.431-2.845-9.966-6.82zm9.966 5.82c3.84 0 7.521-2.503 8.962-6-1.441-3.497-5.122-6-8.962-6-3.841 0-7.521 2.503-8.962 6 1.441 3.497 5.121 6 8.962 6z"/><path d="M11 14.001c0 1.66 1.341 2.999 3.001 2.999s2.999-1.339 2.999-2.999c0-1.66-1.339-3.001-2.999-3.001-1.66 0-3.001 1.341-3.001 3.001z"/></g></svg>'
        },
        Csdk: function(o, e) {
            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><circle fill="currentColor" cx="14" cy="14" r="3"/></svg>'
        },
        FVBd: function(o, e) {
            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><g fill="currentColor" fill-rule="evenodd"><path fill-rule="nonzero" d="M23.002 23C23 23 23 18.003 23 18.003L15.998 18C16 18 16 22.997 16 22.997l7.002.003zM15 18.003A1 1 0 0 1 15.998 17h7.004c.551 0 .998.438.998 1.003v4.994A1 1 0 0 1 23.002 24h-7.004A.993.993 0 0 1 15 22.997v-4.994z"/><path d="M19 20h1v2h-1z"/><path fill-rule="nonzero" d="M22 17.5v-2a2.5 2.5 0 0 0-5 0v2h1v-2a1.5 1.5 0 0 1 3 0v2h1z"/><g fill-rule="nonzero"><path d="M3 14.707A1 1 0 0 1 3.293 14L14.439 2.854a1.5 1.5 0 0 1 2.122 0l2.585 2.585a1.5 1.5 0 0 1 0 2.122L8 18.707a1 1 0 0 1-.707.293H4a1 1 0 0 1-1-1v-3.293zm1 0V18h3.293L18.439 6.854a.5.5 0 0 0 0-.708l-2.585-2.585a.5.5 0 0 0-.708 0L4 14.707z"/><path d="M13.146 4.854l4 4 .708-.708-4-4zm-9 9l4 4 .708-.708-4-4z"/><path d="M15.146 6.146l-9 9 .708.708 9-9z"/></g></g></svg>'
        },
        G1jy: function(o, e) {
            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><g fill="currentColor"><path fill-rule="nonzero" d="M15.039 5.969l-.019-.019-2.828 2.828.707.707 2.474-2.474c1.367-1.367 3.582-1.367 4.949 0s1.367 3.582 0 4.949l-2.474 2.474.707.707 2.828-2.828-.019-.019c1.415-1.767 1.304-4.352-.334-5.99-1.638-1.638-4.224-1.749-5.99-.334zM5.97 15.038l-.019-.019 2.828-2.828.707.707-2.475 2.475c-1.367 1.367-1.367 3.582 0 4.949s3.582 1.367 4.949 0l2.474-2.474.707.707-2.828 2.828-.019-.019c-1.767 1.415-4.352 1.304-5.99-.334-1.638-1.638-1.749-4.224-.334-5.99z"/><path d="M10.485 16.141l5.656-5.656.707.707-5.656 5.656z"/></g></svg>'
        },
        Ijvb: function(o, e, i) {
            "use strict";
            i.d(e, "a", function() {
                return n
            });
            var n = {
                SyncDrawing: i("G1jy"),
                arrow: i("tceb"),
                cursor: i("WHEt"),
                dot: i("Csdk"),
                drawginmode: i("2dtg"),
                drawginmodeActive: i("FVBd"),
                eraser: i("2lje"),
                group: i("lZXH"),
                hideAllDrawings: i("6oLA"),
                hideAllDrawingsActive: i("dmHa"),
                lockAllDrawings: i("Uh5y"),
                lockAllDrawingsActive: i("43BO"),
                magnet: i("3s8f"),
                strongMagnet: i("xjKU"),
                measure: i("oCKS"),
                removeAllDrawingTools: i("aVjL"),
                showObjectTree: i("qQ3E"),
                zoom: i("kmdM"),
                "zoom-out": i("mbEK")
            }
        },
        "MP+M": function(o, e, i) {
            "use strict";
            var n, l, t, a, c, r, s, d;
            i.d(e, "a", function() {
                return d
            }), i("YFKU"), n = i("+GxX"), l = i("ei7k"), i("HbRj"), t = i("zxD0"), a = i("Ijvb"), c = {
                keys: ["Shift"],
                text: window.t("{0} — drawing a straight line at angles of 45")
            }, r = {
                keys: ["Shift"],
                text: window.t("{0} — circle")
            }, s = {
                keys: ["Shift"],
                text: window.t("{0} — square")
            }, d = {
                LineTool5PointsPattern: {
                    icon: t.lineToolsIcons.LineTool5PointsPattern,
                    localizedName: window.t("XABCD Pattern")
                },
                LineToolABCD: {
                    icon: t.lineToolsIcons.LineToolABCD,
                    localizedName: window.t("ABCD Pattern")
                },
                LineToolArc: {
                    icon: t.lineToolsIcons.LineToolArc,
                    localizedName: window.t("Arc")
                },
                LineToolArrow: {
                    icon: t.lineToolsIcons.LineToolArrow,
                    localizedName: window.t("Arrow")
                },
                LineToolArrowMarkDown: {
                    icon: t.lineToolsIcons.LineToolArrowMarkDown,
                    localizedName: window.t("Arrow Mark Down")
                },
                LineToolArrowMarkLeft: {
                    icon: t.lineToolsIcons.LineToolArrowMarkLeft,
                    localizedName: window.t("Arrow Mark Left")
                },
                LineToolArrowMarkRight: {
                    icon: t.lineToolsIcons.LineToolArrowMarkRight,
                    localizedName: window.t("Arrow Mark Right")
                },
                LineToolArrowMarkUp: {
                    icon: t.lineToolsIcons.LineToolArrowMarkUp,
                    localizedName: window.t("Arrow Mark Up")
                },
                LineToolBalloon: {
                    icon: t.lineToolsIcons.LineToolBalloon,
                    localizedName: window.t("Balloon")
                },
                LineToolBarsPattern: {
                    icon: t.lineToolsIcons.LineToolBarsPattern,
                    localizedName: window.t("Bars Pattern")
                },
                LineToolBezierCubic: {
                    icon: t.lineToolsIcons.LineToolBezierCubic,
                    localizedName: window.t("Double Curve")
                },
                LineToolBezierQuadro: {
                    icon: t.lineToolsIcons.LineToolBezierQuadro,
                    localizedName: window.t("Curve")
                },
                LineToolBrush: {
                    icon: t.lineToolsIcons.LineToolBrush,
                    localizedName: window.t("Brush")
                },
                LineToolCallout: {
                    icon: t.lineToolsIcons.LineToolCallout,
                    localizedName: window.t("Callout")
                },
                LineToolCircleLines: {
                    icon: t.lineToolsIcons.LineToolCircleLines,
                    localizedName: window.t("Cyclic Lines")
                },
                LineToolCypherPattern: {
                    icon: t.lineToolsIcons.LineToolCypherPattern,
                    localizedName: window.t("Cypher Pattern")
                },
                LineToolDateAndPriceRange: {
                    icon: t.lineToolsIcons.LineToolDateAndPriceRange,
                    localizedName: window.t("Date and Price Range")
                },
                LineToolDateRange: {
                    icon: t.lineToolsIcons.LineToolDateRange,
                    localizedName: window.t("Date Range")
                },
                LineToolDisjointAngle: {
                    icon: t.lineToolsIcons.LineToolDisjointAngle,
                    localizedName: window.t("Disjoint Angle"),
                    hotKey: Object(l.b)(c)
                },
                LineToolElliottCorrection: {
                    icon: t.lineToolsIcons.LineToolElliottCorrection,
                    localizedName: window.t("Elliott Correction Wave (ABC)")
                },
                LineToolElliottDoubleCombo: {
                    icon: t.lineToolsIcons.LineToolElliottDoubleCombo,
                    localizedName: window.t("Elliott Double Combo Wave (WXY)")
                },
                LineToolElliottImpulse: {
                    icon: t.lineToolsIcons.LineToolElliottImpulse,
                    localizedName: window.t("Elliott Impulse Wave (12345)")
                },
                LineToolElliottTriangle: {
                    icon: t.lineToolsIcons.LineToolElliottTriangle,
                    localizedName: window.t("Elliott Triangle Wave (ABCDE)")
                },
                LineToolElliottTripleCombo: {
                    icon: t.lineToolsIcons.LineToolElliottTripleCombo,
                    localizedName: window.t("Elliott Triple Combo Wave (WXYXZ)")
                },
                LineToolEllipse: {
                    icon: t.lineToolsIcons.LineToolEllipse,
                    localizedName: window.t("Ellipse"),
                    hotKey: Object(l.b)(r)
                },
                LineToolExtended: {
                    icon: t.lineToolsIcons.LineToolExtended,
                    localizedName: window.t("Extended")
                },
                LineToolFibChannel: {
                    icon: t.lineToolsIcons.LineToolFibChannel,
                    localizedName: window.t("Fib Channel")
                },
                LineToolFibCircles: {
                    icon: t.lineToolsIcons.LineToolFibCircles,
                    localizedName: window.t("Fib Circles"),
                    hotKey: Object(l.b)(r)
                },
                LineToolFibRetracement: {
                    icon: t.lineToolsIcons.LineToolFibRetracement,
                    localizedName: window.t("Fib Retracement")
                },
                LineToolFibSpeedResistanceArcs: {
                    icon: t.lineToolsIcons.LineToolFibSpeedResistanceArcs,
                    localizedName: window.t("Fib Speed Resistance Arcs")
                },
                LineToolFibSpeedResistanceFan: {
                    icon: t.lineToolsIcons.LineToolFibSpeedResistanceFan,
                    localizedName: window.t("Fib Speed Resistance Fan"),
                    hotKey: Object(l.b)(s)
                },
                LineToolFibSpiral: {
                    icon: t.lineToolsIcons.LineToolFibSpiral,
                    localizedName: window.t("Fib Spiral")
                },
                LineToolFibTimeZone: {
                    icon: t.lineToolsIcons.LineToolFibTimeZone,
                    localizedName: window.t("Fib Time Zone")
                },
                LineToolFibWedge: {
                    icon: t.lineToolsIcons.LineToolFibWedge,
                    localizedName: window.t("Fib Wedge")
                },
                LineToolFlagMark: {
                    icon: t.lineToolsIcons.LineToolFlagMark,
                    localizedName: window.t("Flag Mark")
                },
                LineToolFlatBottom: {
                    icon: t.lineToolsIcons.LineToolFlatBottom,
                    localizedName: window.t("Flat Top/Bottom"),
                    hotKey: Object(l.b)(c)
                },
                LineToolGannComplex: {
                    icon: t.lineToolsIcons.LineToolGannComplex,
                    localizedName: window.t("Gann Square")
                },
                LineToolGannFixed: {
                    icon: t.lineToolsIcons.LineToolGannFixed,
                    localizedName: window.t("Gann Square Fixed")
                },
                LineToolGannFan: {
                    icon: t.lineToolsIcons.LineToolGannFan,
                    localizedName: window.t("Gann Fan")
                },
                LineToolGannSquare: {
                    icon: t.lineToolsIcons.LineToolGannSquare,
                    localizedName: window.t("Gann Box"),
                    hotKey: Object(l.b)({
                        keys: ["Shift"],
                        text: window.t("{0} — fixed increments")
                    })
                },
                LineToolHeadAndShoulders: {
                    icon: t.lineToolsIcons.LineToolHeadAndShoulders,
                    localizedName: window.t("Head and Shoulders")
                },
                LineToolHorzLine: {
                    icon: t.lineToolsIcons.LineToolHorzLine,
                    localizedName: window.t("Horizontal Line"),
                    hotKey: Object(l.b)({
                        keys: ["Alt", "H"],
                        text: "{0} + {1}"
                    })
                },
                LineToolHorzRay: {
                    icon: t.lineToolsIcons.LineToolHorzRay,
                    localizedName: window.t("Horizontal Ray")
                },
                LineToolIcon: {
                    icon: t.lineToolsIcons.LineToolIcon,
                    localizedName: window.t("Font Icons")
                },
                LineToolInsidePitchfork: {
                    icon: t.lineToolsIcons.LineToolInsidePitchfork,
                    localizedName: window.t("Inside Pitchfork")
                },
                LineToolNote: {
                    icon: t.lineToolsIcons.LineToolNote,
                    localizedName: window.t("Note")
                },
                LineToolNoteAbsolute: {
                    icon: t.lineToolsIcons.LineToolNoteAbsolute,
                    localizedName: window.t("Anchored Note")
                },
                LineToolParallelChannel: {
                    icon: t.lineToolsIcons.LineToolParallelChannel,
                    localizedName: window.t("Parallel Channel"),
                    hotKey: Object(l.b)(c)
                },
                LineToolPitchfan: {
                    icon: t.lineToolsIcons.LineToolPitchfan,
                    localizedName: window.t("Pitchfan")
                },
                LineToolPitchfork: {
                    icon: t.lineToolsIcons.LineToolPitchfork,
                    localizedName: window.t("Pitchfork")
                },
                LineToolPolyline: {
                    icon: t.lineToolsIcons.LineToolPolyline,
                    localizedName: window.t("Polyline")
                },
                LineToolPrediction: {
                    icon: t.lineToolsIcons.LineToolPrediction,
                    localizedName: window.t("Forecast")
                },
                LineToolPriceLabel: {
                    icon: t.lineToolsIcons.LineToolPriceLabel,
                    localizedName: window.t("Price Label")
                },
                LineToolPriceRange: {
                    icon: t.lineToolsIcons.LineToolPriceRange,
                    localizedName: window.t("Price Range")
                },
                LineToolProjection: {
                    icon: t.lineToolsIcons.LineToolProjection,
                    localizedName: window.t("Projection")
                },
                LineToolRay: {
                    icon: t.lineToolsIcons.LineToolRay,
                    localizedName: window.t("Ray")
                },
                LineToolRectangle: {
                    icon: t.lineToolsIcons.LineToolRectangle,
                    localizedName: window.t("Rectangle"),
                    hotKey: Object(l.b)({
                        keys: ["Shift"],
                        text: window.t("{0} — square")
                    })
                },
                LineToolRegressionTrend: {
                    icon: t.lineToolsIcons.LineToolRegressionTrend,
                    localizedName: window.t("Regression Trend")
                },
                LineToolRiskRewardLong: {
                    icon: t.lineToolsIcons.LineToolRiskRewardLong,
                    localizedName: window.t("Long Position")
                },
                LineToolRiskRewardShort: {
                    icon: t.lineToolsIcons.LineToolRiskRewardShort,
                    localizedName: window.t("Short Position")
                },
                LineToolRotatedRectangle: {
                    icon: t.lineToolsIcons.LineToolRotatedRectangle,
                    localizedName: window.t("Rotated Rectangle"),
                    hotKey: Object(l.b)(c)
                },
                LineToolSchiffPitchfork: {
                    icon: t.lineToolsIcons.LineToolSchiffPitchfork,
                    localizedName: window.t("Modified Schiff Pitchfork")
                },
                LineToolSchiffPitchfork2: {
                    icon: t.lineToolsIcons.LineToolSchiffPitchfork2,
                    localizedName: window.t("Schiff Pitchfork")
                },
                LineToolSineLine: {
                    icon: t.lineToolsIcons.LineToolSineLine,
                    localizedName: window.t("Sine Line")
                },
                LineToolText: {
                    icon: t.lineToolsIcons.LineToolText,
                    localizedName: window.t("Text", {
                        context: "tool"
                    })
                },
                LineToolTextAbsolute: {
                    icon: t.lineToolsIcons.LineToolTextAbsolute,
                    localizedName: window.t("Anchored Text")
                },
                LineToolThreeDrivers: {
                    icon: t.lineToolsIcons.LineToolThreeDrivers,
                    localizedName: window.t("Three Drives Pattern")
                },
                LineToolTimeCycles: {
                    icon: t.lineToolsIcons.LineToolTimeCycles,
                    localizedName: window.t("Time Cycles")
                },
                LineToolTrendAngle: {
                    icon: t.lineToolsIcons.LineToolTrendAngle,
                    localizedName: window.t("Trend Angle"),
                    hotKey: Object(l.b)(c)
                },
                LineToolTrendBasedFibExtension: {
                    icon: t.lineToolsIcons.LineToolTrendBasedFibExtension,
                    localizedName: window.t("Trend-Based Fib Extension")
                },
                LineToolTrendBasedFibTime: {
                    icon: t.lineToolsIcons.LineToolTrendBasedFibTime,
                    localizedName: window.t("Trend-Based Fib Time")
                },
                LineToolTrendLine: {
                    icon: t.lineToolsIcons.LineToolTrendLine,
                    localizedName: window.t("Trend Line"),
                    hotKey: Object(l.b)(c)
                },
                LineToolInfoLine: {
                    icon: t.lineToolsIcons.LineToolInfoLine,
                    localizedName: window.t("Info Line")
                },
                LineToolTriangle: {
                    icon: t.lineToolsIcons.LineToolTriangle,
                    localizedName: window.t("Triangle")
                },
                LineToolTrianglePattern: {
                    icon: t.lineToolsIcons.LineToolTrianglePattern,
                    localizedName: window.t("Triangle Pattern")
                },
                LineToolVertLine: {
                    icon: t.lineToolsIcons.LineToolVertLine,
                    localizedName: window.t("Vertical Line"),
                    hotKey: Object(l.b)({
                        keys: ["Alt", "V"],
                        text: "{0} + {1}"
                    })
                },
                LineToolCrossLine: {
                    icon: t.lineToolsIcons.LineToolCrossLine,
                    localizedName: $.t("Cross Line")
                },
                SyncDrawing: {
                    icon: a.a.SyncDrawing,
                    iconActive: a.a.SyncDrawingActive,
                    localizedName: window.t("New drawings are replicated to all charts in the layout and shown when the same ticker is selected")
                },
                arrow: {
                    icon: a.a.arrow,
                    localizedName: window.t("Arrow")
                },
                cursor: {
                    icon: a.a.cursor,
                    localizedName: window.t("Cross")
                },
                dot: {
                    icon: a.a.dot,
                    localizedName: window.t("Dot")
                },
                drawginmode: {
                    icon: a.a.drawginmode,
                    iconActive: a.a.drawginmodeActive,
                    localizedName: window.t("Stay in Drawing Mode")
                },
                eraser: {
                    icon: a.a.eraser,
                    localizedName: window.t("Eraser")
                },
                group: {
                    icon: a.a.group,
                    localizedName: window.t("Show Hidden Tools")
                },
                hideAllDrawings: {
                    icon: a.a.hideAllDrawings,
                    iconActive: a.a.hideAllDrawingsActive,
                    localizedName: window.t("Hide All Drawing Tools")
                },
                lockAllDrawings: {
                    icon: a.a.lockAllDrawings,
                    iconActive: a.a.lockAllDrawingsActive,
                    localizedName: window.t("Lock All Drawing Tools")
                },
                magnet: {
                    icon: a.a.magnet,
                    localizedName: window.t("Magnet Mode snaps drawings placed near price bars to the closest OHLC value"),
                    hotKey: Object(l.b)({
                        keys: ["Ctrl"],
                        text: "{0}"
                    })
                },
                measure: {
                    icon: a.a.measure,
                    localizedName: window.t("Measure"),
                    hotKey: Object(l.b)({
                        keys: ["Shift"],
                        text: window.t("{0} + Click on the chart")
                    })
                },
                removeAllDrawingTools: {
                    icon: a.a.removeAllDrawingTools,
                    localizedName: window.t("Remove All Drawing Tools")
                },
                showObjectsTree: {
                    icon: a.a.showObjectTree,
                    localizedName: window.t("Show Object Tree")
                },
                zoom: {
                    icon: a.a.zoom,
                    localizedName: window.t("Zoom In")
                },
                "zoom-out": {
                    icon: a.a["zoom-out"],
                    localizedName: window.t("Zoom Out")
                }
            }, Object(n.isFeatureEnabled)("remove-line-tool-ghost-feed") || (d.LineToolGhostFeed = {
                icon: t.lineToolsIcons.LineToolGhostFeed,
                localizedName: window.t("Ghost Feed")
            })
        },
        Uh5y: function(o, e) {
            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="m6 13a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2m1 0a2 2 0 0 0 1 1h12a2 2 0 0 0 1-1v-9a2 2 0 0 0-1-1H8a2 2 0 0 0-1 1m6 5a1 1 0 0 1 2 0v2a1 1 0 0 1-2 0m-3-9V7a1 1 0 0 1 8 0h-1a1 1 0 0 0-6 0v4"/></svg>'
        },
        WHEt: function(o, e) {
            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><g fill="currentColor"><path d="M18 15h8v-1h-8z"/><path d="M14 18v8h1v-8zM14 3v8h1v-8zM3 15h8v-1h-8z"/></g></svg>'
        },
        aVjL: function(o, e) {
            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><g fill="currentColor"><path fill-rule="nonzero" d="M8 21c0 1.1.825 2 1.833 2h7.333c1.008 0 1.833-.9 1.833-2v-12h-11v12zm-1 0v-13h13v13c0 1.634-1.252 3-2.833 3h-7.333c-1.581 0-2.833-1.366-2.833-3z"/><path d="M17 6l-1-1h-5l-1 1h-3v1h13v-1z"/><path fill-rule="nonzero" d="M10 11v9.062h1v-9.062z"/><path fill-rule="nonzero" d="M13 11v9.062h1v-9.062z"/><path fill-rule="nonzero" d="M16 11v9.062h1v-9.062z"/></g></svg>'
        },
        b2d7: function(o, e, i) {
            "use strict";
            var n, l, t, a, c;
            i.d(e, "a", function() {
                    return c
                }), n = i("aIyQ"), l = i.n(n), t = i("Vdly"),
                function(o) {
                    function e() {
                        o.favorites = [], Object(t.getJSON)("chart.favoriteDrawings", []).forEach(function(e) {
                            o.favorites.push(e.tool || e)
                        }), o.favoritesSynced.fire()
                    }
                    o.favorites = [], o.favoritesSynced = new l.a, o.favoriteIndex = function(e) {
                        return o.favorites.indexOf(e)
                    }, o.saveFavorites = function() {
                        Object(t.setJSON)("chart.favoriteDrawings", o.favorites)
                    }, e(), t.onSync.subscribe(null, e)
                }(a || (a = {})),
                function(o) {
                    function e() {
                        return a.favorites.length
                    }

                    function i(o) {
                        return -1 !== a.favoriteIndex(o)
                    }
                    o.favoriteAdded = new l.a, o.favoriteRemoved = new l.a, o.favoriteMoved = new l.a, o.favoritesSynced = a.favoritesSynced, o.favorites = function() {
                        return a.favorites.slice()
                    }, o.favoritesCount = e, o.favorite = function(o) {
                        return o < 0 || o >= e() ? "" : a.favorites[o]
                    }, o.addFavorite = function(e) {
                        return !i(e) && (a.favorites.push(e), a.saveFavorites(), o.favoriteAdded.fire(e), !0)
                    }, o.removeFavorite = function(e) {
                        var i = a.favoriteIndex(e);
                        return -1 !== i && (a.favorites.splice(i, 1), a.saveFavorites(), o.favoriteRemoved.fire(e), !0)
                    }, o.isFavorite = i, o.moveFavorite = function(i, n) {
                        if (n < 0 || n >= e()) return !1;
                        var l = a.favoriteIndex(i);
                        return -1 !== l && n !== l && (a.favorites.splice(l, 1), a.favorites.splice(n, 0, i), a.saveFavorites(), o.favoriteMoved.fire(i, l, n), !0)
                    }
                }(c || (c = {}))
        },
        dmHa: function(o, e) {
            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" fill-rule="nonzero" d="M17.537 7.635l-.789.789c-.886-.275-1.812-.424-2.748-.424-3.841 0-7.521 2.503-8.962 6 .562 1.364 1.465 2.577 2.585 3.549l-.709.709c-1.265-1.112-2.274-2.506-2.881-4.077l-.07-.18.07-.18c1.535-3.975 5.645-6.82 9.966-6.82 1.213 0 2.409.224 3.537.635zm3.549 2.108c1.265 1.112 2.274 2.506 2.881 4.077l.07.18-.07.18c-1.535 3.975-5.646 6.82-9.966 6.82-1.213 0-2.409-.224-3.537-.635l.789-.789c.886.275 1.812.424 2.748.424 3.84 0 7.521-2.503 8.962-6-.562-1.364-1.465-2.577-2.585-3.549l.709-.709zm-6.049.392l-4.902 4.902c-.088-.33-.135-.677-.135-1.036 0-2.213 1.788-4.001 4.001-4.001.358 0 .705.047 1.036.135zm2.828 2.829c.088.331.135.679.135 1.038 0 2.213-1.786 3.999-3.999 3.999-.359 0-.707-.047-1.038-.135l4.901-4.901zm-12.365 10.243l-.707-.707 17.707-17.707.707.707-17.707 17.707z"/></svg>'
        },
        kmdM: function(o, e) {
            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="currentColor"><path d="M17.646 18.354l4 4 .708-.708-4-4z"/><path d="M12.5 21a8.5 8.5 0 1 1 0-17 8.5 8.5 0 0 1 0 17zm0-1a7.5 7.5 0 1 0 0-15 7.5 7.5 0 0 0 0 15z"/><path d="M9 13h7v-1H9z"/><path d="M13 16V9h-1v7z"/></svg>'
        },
        lZXH: function(o, e) {
            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30" width="30" height="30"><path fill="currentColor" d="M5.5 13A2.5 2.5 0 0 0 3 15.5 2.5 2.5 0 0 0 5.5 18 2.5 2.5 0 0 0 8 15.5 2.5 2.5 0 0 0 5.5 13zm9.5 0a2.5 2.5 0 0 0-2.5 2.5A2.5 2.5 0 0 0 15 18a2.5 2.5 0 0 0 2.5-2.5A2.5 2.5 0 0 0 15 13zm9.5 0a2.5 2.5 0 0 0-2.5 2.5 2.5 2.5 0 0 0 2.5 2.5 2.5 2.5 0 0 0 2.5-2.5 2.5 2.5 0 0 0-2.5-2.5z"/></svg>'
        },
        mbEK: function(o, e) {
            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="currentColor"><path d="M17.646 18.354l4 4 .708-.708-4-4z"/><path d="M12.5 21a8.5 8.5 0 1 1 0-17 8.5 8.5 0 0 1 0 17zm0-1a7.5 7.5 0 1 0 0-15 7.5 7.5 0 0 0 0 15z"/><path d="M9 13h7v-1H9z"/></svg>'
        },
        oCKS: function(o, e) {
            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><path fill="currentColor" d="M2 9.75a1.5 1.5 0 0 0-1.5 1.5v5.5a1.5 1.5 0 0 0 1.5 1.5h24a1.5 1.5 0 0 0 1.5-1.5v-5.5a1.5 1.5 0 0 0-1.5-1.5zm0 1h3v2.5h1v-2.5h3.25v3.9h1v-3.9h3.25v2.5h1v-2.5h3.25v3.9h1v-3.9H22v2.5h1v-2.5h3a.5.5 0 0 1 .5.5v5.5a.5.5 0 0 1-.5.5H2a.5.5 0 0 1-.5-.5v-5.5a.5.5 0 0 1 .5-.5z" transform="rotate(-45 14 14)"/></svg>'
        },
        qQ3E: function(o, e) {
            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><g fill="currentColor"><path fill-rule="nonzero" d="M14 18.634l-.307-.239-7.37-5.73-2.137-1.665 9.814-7.633 9.816 7.634-.509.394-1.639 1.269-7.667 5.969zm7.054-6.759l1.131-.876-8.184-6.366-8.186 6.367 1.123.875 7.063 5.491 7.054-5.492z"/><path d="M7 14.5l-1 .57 8 6.43 8-6.5-1-.5-7 5.5z"/><path d="M7 17.5l-1 .57 8 6.43 8-6.5-1-.5-7 5.5z"/></g></svg>'
        },
        tceb: function(o, e) {
            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M11.682 16.09l3.504 6.068 1.732-1-3.497-6.057 3.595-2.1L8 7.74v10.512l3.682-2.163zm-.362 1.372L7 20V6l12 7-4.216 2.462 3.5 6.062-3.464 2-3.5-6.062z"/></svg>'
        },
        xjKU: function(o, e) {
            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" fill-rule="nonzero" d="M14 5a7 7 0 0 0-7 7v3h4v-3a3 3 0 1 1 6 0v3h4v-3a7 7 0 0 0-7-7zm7 11h-4v3h4v-3zm-10 0H7v3h4v-3zm-5-4a8 8 0 1 1 16 0v8h-6v-8a2 2 0 1 0-4 0v8H6v-8zm3.293 11.294l-1.222-2.037.858-.514 1.777 2.963-2 1 1.223 2.037-.858.514-1.778-2.963 2-1zm9.778-2.551l.858.514-1.223 2.037 2 1-1.777 2.963-.858-.514 1.223-2.037-2-1 1.777-2.963z"/></svg>'
        }
    }
]);